/*

An in-memory session store implementation.

*/

package session

import (
	"fmt"
	"io/ioutil"
	"log"
	"sync"
	"time"
)

/* 内存 session 保存 实现*/
type inMemStore struct {
	sessions    map[string]Session     // Map of sessions (mapped from ID)
	mux         *sync.RWMutex          // mutex to synchronize access to sessions
	ticker      *time.Ticker           // session cleaner 使用的 定时器
	closeTicker chan struct{}          // 通知 session cleaner 所在 goroutine 进行关闭
	logPrintln  func(v ...interface{}) // Function used to log session lifecycle events (e.g. added, removed, timed out).
}

/* 禁止logging 对象*/
var NoopLogger = log.New(ioutil.Discard, "", 0)

/* 定义 在创建 内存Store对象时 传递进入的参数
1. 所有字段都是可选的
2. 默认值均为 零值
*/
type InMemStoreOptions struct {
	/* Session cleaner 执行间隔时间，默认时 10S*/
	SessCleanerInterval time.Duration

	/* Logger: 打印 session 生命周期事件*/
	Logger *log.Logger
}

// Pointer to zero value of InMemStoreOptions to be reused for efficiency.
var zeroInMemStoreOptions = new(InMemStoreOptions)

// NewInMemStore returns a new, in-memory session Store with the default options.
// Default values of options are listed in the InMemStoreOptions type.
// The returned Store has an automatic session cleaner which runs
// in its own goroutine.
func NewInMemStore() Store {
	return NewInMemStoreOptions(zeroInMemStoreOptions)
}

// NewInMemStoreOptions returns a new, in-memory session Store with the specified options.
// The returned Store has an automatic session cleaner which runs
// in its own goroutine.
func NewInMemStoreOptions(o *InMemStoreOptions) Store {
	s := &inMemStore{
		sessions:    make(map[string]Session),
		mux:         &sync.RWMutex{},
		closeTicker: make(chan struct{}),
	}

	output := log.Output
	if o.Logger != nil {
		output = o.Logger.Output
	}
	s.logPrintln = func(v ...interface{}) {
		output(3, fmt.Sprintln(v...))
	}

	interval := o.SessCleanerInterval
	if interval == 0 {
		interval = 10 * time.Second
	}

	go s.sessCleaner(interval)

	return s
}

/* sessCleaner： 周期性 检查 sessions 是否已经 超时
1. 删除超时的 session
2. 在 新goroutine 中执行
*/
func (s *inMemStore) sessCleaner(interval time.Duration) {
	ticker := time.NewTicker(interval)

	for {
		select {
		case <-s.closeTicker:
			/* 接收到 关闭 通知 */
			ticker.Stop()
			return
		case now := <-ticker.C:
			/* 由于 相较于 需要 check 的个数，需要删除的个数特别少
			1. 使用 Read 锁 来遍历，如果有需要 删除的，继续后续步骤，否则跳过
				（对于 check 个数很多时，不会卡住特别长时间)
			2. 如有需要删除，再次遍历*/
			needRemove := func() bool {
				s.mux.RLock() // Read lock is enough
				defer s.mux.RUnlock()

				for _, sess := range s.sessions {
					if now.Sub(sess.Accessed()) > sess.Timeout() {
						return true
					}
				}
				return false
			}()
			if !needRemove {
				continue
			}

			// Remove required:
			func() {
				s.mux.Lock() // Read-write lock required
				defer s.mux.Unlock()

				for _, sess := range s.sessions {
					if now.Sub(sess.Accessed()) > sess.Timeout() {
						s.logPrintln("Session timed out:", sess.ID())
						delete(s.sessions, sess.ID())
					}
				}
			}()
		}
	}
}

// Get is to implement Store.Get().
func (s *inMemStore) Get(id string) Session {
	s.mux.RLock()
	defer s.mux.RUnlock()

	sess := s.sessions[id]
	if sess == nil {
		return nil
	}

	// 更新 sess 的 访问时间
	sess.Access()
	return sess
}

// Add is to implement Store.Add().
func (s *inMemStore) Add(sess Session) {
	s.mux.Lock()
	defer s.mux.Unlock()

	s.logPrintln("Session added:", sess.ID())
	s.sessions[sess.ID()] = sess
}

// Remove is to implement Store.Remove().
func (s *inMemStore) Remove(sess Session) {
	s.mux.Lock()
	defer s.mux.Unlock()

	s.logPrintln("Session removed:", sess.ID())
	delete(s.sessions, sess.ID())
}

// Close is to implement Store.Close().
func (s *inMemStore) Close() {
	close(s.closeTicker)
}
