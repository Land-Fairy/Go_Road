/*

Session interface and its implementation.

*/

package session

import (
	"crypto/rand"
	"encoding/base64"
	"io"
	"sync"
	"time"
)

/*
	Session: HTTP session 接口
	作用: 存/取 变量/常量
*/
type Session interface {
	/*
		返回 session ID
	*/
	ID() string

	/*
		返回 该 session 是否是 新创建的
		实现: 比较 created 和 access 时间 是否相等
	*/
	New() bool

	/* 返回 name 对应的 属性值(在session创建时设置的)
	1. 该属性 在 session 的生存周期内 不可被修改
	2. 由于 无法修改，因此 即使不用 同步，也可以 被并发的 安全访问
	*/
	CAttr(name string) interface{}

	/* 返回 session 中 保存的 name 对应属性值
	1. 可并发 使用
	*/
	Attr(name string) interface{}

	/* 设置 session 中 name 对应的属性值
	1. 如果传递的为nil， 则结果为 删除 该 属性
	2. 可并发的安全使用
	*/
	SetAttr(name string, value interface{})

	/* 返回 session 中 保存的 所有 属性的 拷贝
	1. 可并发的安全使用
	*/
	Attrs() map[string]interface{}

	/* 返回  session 的 创建时间*/
	Created() time.Time

	/* 返回 session 最后一次 被访问的 时间*/
	Accessed() time.Time

	/* 返回 session 的超时时间
	1. 超时后会被自动删除
	*/
	Timeout() time.Duration

	/* 返回 session 的 读写锁
	1. 用来 同步 修改/读取 session 中 字段值
	2. 当 session 级别的 同步需要时 使用
	// Important! If Session values are marshalled / unmarshalled
	// (e.g. multi server instance environment such as Google AppEngine),
	// this mutex may be different for each Session value and thus
	// it can only be used to session-value level synchronization!
	*/

	Mutex() *sync.RWMutex

	/*
		注册 一个对 session 的 访问
		1. 更新 最后访问时间
		2. Users 不需要调用该方法
	*/
	Access()
}

/* Session 接口 的 实现
 */
// Fields are exported so a session may be marshalled / unmarshalled.
type sessionImpl struct {
	IDF       string                 // ID of the session
	CreatedF  time.Time              // Creation time
	AccessedF time.Time              // Last accessed time
	CAttrsF   map[string]interface{} // Constant attributes specified at session creation
	AttrsF    map[string]interface{} // Attributes stored in the session
	TimeoutF  time.Duration          // Session timeout
	mux       *sync.RWMutex          // RW mutex to synchronize session state access
}

/* SessOptions：创建新Session时，可被传入的 options
1. 所有字段都是可选的
2. 默认值均为 零值
*/
type SessOptions struct {
	/* Session 中的常量属性
	1. 可通过 Session.CAttr() 来访问 （无同步方式）
	2. map 值会被 拷贝
	3. 可通过 Session.CAttr() 方法进行访问
	*/
	CAttrs map[string]interface{}

	/* 最初始，将要存储在 session 中的 非常量属性
	1. map 中的值 会被拷贝
	2. 可以通过 Session.Attr() 或 Session.Attrs 方法 访问
	3. 可通过 Session.SetAttr() 方法来访问
	*/
	Attrs map[string]interface{}

	/* 超时时间，默认30分钟*/
	Timeout time.Duration

	/* 构建 session id 所使用 信息 的 长度
		1. 使用 Base-64 编码，id 的长度 为 4/3 chars
	    2. 默认值为18 （此时 id 长度 为 24）
	*/
	IDLength int
}

/*
	SessOptions 的零值 指针。 可被高效的 重用
*/
var zeroSessOptions = new(SessOptions)

/*	使用 默认 options 创建 一个 session
 */
func NewSession() Session {
	return NewSessionOptions(zeroSessOptions)
}

/* 使用 特定的 options 来创建 session
 */
func NewSessionOptions(o *SessOptions) Session {
	now := time.Now()
	idLength := o.IDLength
	if idLength <= 0 {
		idLength = 18
	}
	timeout := o.Timeout
	if timeout == 0 {
		timeout = 30 * time.Minute
	}

	sess := sessionImpl{
		/* 生成 随机 ID*/
		IDF:       genID(idLength),
		CreatedF:  now,
		AccessedF: now,
		AttrsF:    make(map[string]interface{}),
		TimeoutF:  timeout,
		mux:       &sync.RWMutex{},
	}

	if len(o.CAttrs) > 0 {
		sess.CAttrsF = make(map[string]interface{}, len(o.CAttrs))
		for k, v := range o.CAttrs {
			sess.CAttrsF[k] = v
		}
	}

	for k, v := range o.Attrs {
		sess.AttrsF[k] = v
	}

	return &sess
}

/* 生成 一个 安全，随机的 session id
 */
func genID(length int) string {
	r := make([]byte, length)
	/* 读取 rand.Reader (随机)*/
	io.ReadFull(rand.Reader, r)
	/* base64 进行编码*/
	return base64.URLEncoding.EncodeToString(r)
}

// ID is to implement Session.ID().
func (s *sessionImpl) ID() string {
	return s.IDF
}

// New is to implement Session.New().
func (s *sessionImpl) New() bool {
	return s.CreatedF == s.AccessedF
}

// CAttr is to implement Session.CAttr().
func (s *sessionImpl) CAttr(name string) interface{} {
	return s.CAttrsF[name]
}

// Attr is to implement Session.Attr().
func (s *sessionImpl) Attr(name string) interface{} {
	s.mux.RLock()
	defer s.mux.RUnlock()

	return s.AttrsF[name]
}

// SetAttr is to implement Session.SetAttr().
func (s *sessionImpl) SetAttr(name string, value interface{}) {
	s.mux.Lock()
	defer s.mux.Unlock()

	if value == nil {
		delete(s.AttrsF, name)
	} else {
		s.AttrsF[name] = value
	}
}

// Attrs is to implement Session.Attrs().
func (s *sessionImpl) Attrs() map[string]interface{} {
	s.mux.RLock()
	defer s.mux.RUnlock()

	m := make(map[string]interface{}, len(s.AttrsF))
	for k, v := range s.AttrsF {
		m[k] = v
	}
	return m
}

// Created is to implement Session.Created().
func (s *sessionImpl) Created() time.Time {
	return s.CreatedF
}

// Accessed is to implement Session.Accessed().
func (s *sessionImpl) Accessed() time.Time {
	s.mux.RLock()
	defer s.mux.RUnlock()

	return s.AccessedF
}

// Timeout is to implement Session.Timeout().
func (s *sessionImpl) Timeout() time.Duration {
	return s.TimeoutF
}

// Mutex is to implement Session.Mutex().
func (s *sessionImpl) Mutex() *sync.RWMutex {
	return s.mux
}

// Access is to implement Session.Access().
func (s *sessionImpl) Access() {
	s.mux.Lock()
	defer s.mux.Unlock()

	s.AccessedF = time.Now()
}
