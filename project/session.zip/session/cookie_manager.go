/*

A secure, cookie based session Manager implementation.

*/

package session

import (
	"net/http"
	"time"
)

/* CookieManager： 安全的， 基于 cookie的 session 管理 实现
1. 客户端只保存 session ID， 并使用 cookie 进行管理*/
type CookieManager struct {
	store Store // 后台的 Store

	sessIDCookieName string // 用来保存 sessionId 的 cookie 名称
	cookieSecure     bool   // 是否只在 HTTPS 下进行使用
	cookieMaxAgeSec  int    // cookie 最大生存时间
	cookiePath       string // 使用的 cookie 路径
}

/* CookieMngrOptions: 定义 在创建 CookieManager 时 可能传入的 options
1. 所有字段都是 可选的
2. 字段默认值都是 零值
*/
type CookieMngrOptions struct {
	/* 用来保存 sessionId 的 cookie名称: 默认为 sessid*/
	SessIDCookieName string

	/* session id cookie 是否被运行在 HTTP 下使用，默认为 false*/
	AllowHTTP bool

	/* session id cookie 的最大生存时间，默认为 30天 */
	CookieMaxAge time.Duration

	/* cookie 路径，默认值为 / */
	CookiePath string
}

// Pointer to zero value of CookieMngrOptions to be reused for efficiency.
var zeroCookieMngrOptions = new(CookieMngrOptions)

// NewCookieManager creates a new, cookie based session Manager with default options.
// Default values of options are listed in the CookieMngrOptions type.
func NewCookieManager(store Store) Manager {
	return NewCookieManagerOptions(store, zeroCookieMngrOptions)
}

// NewCookieManagerOptions creates a new, cookie based session Manager with the specified options.
func NewCookieManagerOptions(store Store, o *CookieMngrOptions) Manager {
	m := &CookieManager{
		store:            store,
		cookieSecure:     !o.AllowHTTP,
		sessIDCookieName: o.SessIDCookieName,
		cookiePath:       o.CookiePath,
	}

	if m.sessIDCookieName == "" {
		m.sessIDCookieName = "sessid"
	}
	if o.CookieMaxAge == 0 {
		m.cookieMaxAgeSec = 30 * 24 * 60 * 60 // 30 days max age
	} else {
		m.cookieMaxAgeSec = int(o.CookieMaxAge.Seconds())
	}
	if m.cookiePath == "" {
		m.cookiePath = "/"
	}

	return m
}

// Get is to implement Manager.Get().
func (m *CookieManager) Get(r *http.Request) Session {
	c, err := r.Cookie(m.sessIDCookieName)
	if err != nil {
		return nil
	}

	return m.store.Get(c.Value)
}

// Add is to implement Manager.Add().
func (m *CookieManager) Add(sess Session, w http.ResponseWriter) {
	/*	HttpOnly: 不允许 非 HTTP 请求（主要是 js，防止 XSS攻击) */
	// Secure: only send it over HTTPS
	// MaxAge: to specify the max age of the cookie in seconds, else it's a session cookie and gets deleted after the browser is closed.

	c := http.Cookie{
		Name:     m.sessIDCookieName,
		Value:    sess.ID(),
		Path:     m.cookiePath,
		HttpOnly: true,
		Secure:   m.cookieSecure,
		MaxAge:   m.cookieMaxAgeSec,
	}
	http.SetCookie(w, &c)

	m.store.Add(sess)
}

// Remove is to implement Manager.Remove().
func (m *CookieManager) Remove(sess Session, w http.ResponseWriter) {
	// Set the cookie with empty value and 0 max age
	c := http.Cookie{
		Name:     m.sessIDCookieName,
		Value:    "",
		Path:     m.cookiePath,
		HttpOnly: true,
		Secure:   m.cookieSecure,
		MaxAge:   -1, // MaxAge<0 means delete cookie now, equivalently 'Max-Age: 0'
	}
	http.SetCookie(w, &c)

	m.store.Remove(sess)
}

// Close is to implement Manager.Close().
func (m *CookieManager) Close() {
	m.store.Close()
}

// SessIDCookieName returns the name of the cookie used for storing the session ID.
func (m *CookieManager) SessIDCookieName() string {
	return m.sessIDCookieName
}

// CookieSecure tells if session ID cookies are to be sent only over HTTPS.
func (m *CookieManager) CookieSecure() bool {
	return m.cookieSecure
}

// CookieMaxAgeSec returns the Max age for session ID cookies in seconds.
func (m *CookieManager) CookieMaxAgeSec() int {
	return m.cookieMaxAgeSec
}

// CookiePath returns the used cookie path.
func (m *CookieManager) CookiePath() string {
	return m.cookiePath
}
