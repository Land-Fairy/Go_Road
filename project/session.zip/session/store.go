/*

Session Store interface.

*/

package session

/* Store: session 保存 接口
1. 保存 sessions
2. 在服务端，可通过 ID 来获取
*/
type Store interface {
	/* 返回 id 指定的 session
	1. 返回的 session 会自动更新过 access time
	2. 如果未找到，返回 nil
	*/
	Get(id string) Session

	/* 增加 一个 新的 session 到 store 中*/
	Add(sess Session)

	/* 从 store 中 删除 一个 session*/
	Remove(sess Session)

	/* 关闭 session store， 释放 所有已申请的资源*/
	Close()
}
