/*

Session Manager interface.

*/

package session

import (
	"net/http"
)

/*	Manager: session 管理接口
	1. 从 HTTP request 中 获取一个 Session
	2. 在 HTTP response 中 添加 一个 Session
	3. 有一个 后台的 Store，用来 在 server 端 管理 Session的值
*/
type Manager interface {
	/* 返回 HTTP request 中的 session
	1. 如果不包含session 或 该manager 识别不到该 session，返回 nil
	*/
	Get(r *http.Request) Session

	/* 添加 session 到 HTTP Response*/
	Add(sess Session, w http.ResponseWriter)

	/* 从 HTTP Response 中 删除 session*/
	Remove(sess Session, w http.ResponseWriter)

	/* 关闭 manager，并释放所有分配的资源*/
	Close()
}
