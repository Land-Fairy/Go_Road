/* 定义一个 默认的 session manager, 并 定义 代理方法(简便写法)
 */

package session

import (
	"net/http"
)

/* Global: 是一个 默认的 session Manager
 */
var Global = NewCookieManager(NewInMemStore())

/* Get: 为 Global.Get()的 代理方法(简便写法)
 */
func Get(r *http.Request) Session {
	return Global.Get(r)
}

// Add delegates to Global.Add(); adds the session to the HTTP response.
// This means to let the client know about the specified session by including the sesison id in the response somehow.
func Add(sess Session, w http.ResponseWriter) {
	Global.Add(sess, w)
}

// Remove delegates to Global.Remove(); removes the session from the HTTP response.
func Remove(sess Session, w http.ResponseWriter) {
	Global.Remove(sess, w)
}

// Close delegates to Global.Close(); closes the session manager, releasing any resources that were allocated.
func Close() {
	Global.Close()
}
