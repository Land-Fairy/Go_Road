* 结构
    * session.go
        1. 定义session 的 接口 
        2. 定义 session 的基本结构，并实现 接口
    * store.go
        定义 保存/获取 session 的方法
    * inmem_sotre.go
        实现 store 的接口 （内存方式)
        * 使用 map key-sessionID, val-session 方式保存
        * 使用 RWLock 进行 同步
        * 定时删除 过期的 session
    * manager.go
        定义 session 管理的接口
        * 从 request 中 获取 sesion
        * 写入 session 到 response
        * 删除 session
    * cookie_manager.go (供外部使用)
        实现 manager.go 接口
        * 使用 cookie 来 与 客户端 交换 sessionID
        * 包含cookie 的基本使用信息: 路径，httpOnly（重要),过期时间，cookie名称等
        * 包含 一个 Store 对象，用来保存 session
        * 包含 session 的 获取/发送 操作
    * global.go (可以直接使用其中的 manager 接口方法)
        定义了 一个 默认的 manager
        * 定义了 一组方法，直接使用，内部已经创建了 manager
        