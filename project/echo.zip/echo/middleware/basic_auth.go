package middleware

import (
	"encoding/base64"
	"strconv"
	"strings"

	"github.com/labstack/echo/v4"
)

type (
	// BasicAuthConfig defines the config for BasicAuth middleware.
	BasicAuthConfig struct {
		// 是否跳过 中间件
		Skipper Skipper

		// Validator is a function to validate BasicAuth credentials.
		// Required.
		Validator BasicAuthValidator

		// Realm is a string to define realm attribute of BasicAuth.
		// Default value "Restricted".
		Realm string
	}

	// 该方法：用来 验证 传入的 username, passwd
	BasicAuthValidator func(string, string, echo.Context) (bool, error)
)

const (
	basic        = "basic"
	defaultRealm = "Restricted"
)

var (
	// DefaultBasicAuthConfig is the default BasicAuth middleware config.
	DefaultBasicAuthConfig = BasicAuthConfig{
		Skipper: DefaultSkipper,
		Realm:   defaultRealm,
	}
)

/*
	BasicAuth： 返回一个 BasicAuth 中间件
	1> 认证通过，调用 next 方法
	2> 认证错误，返回 401 错误，并设置 Response Header
 */
//
func BasicAuth(fn BasicAuthValidator) echo.MiddlewareFunc {
	// 使用默认的 Config
	c := DefaultBasicAuthConfig
	// 验证方法
	c.Validator = fn
	return BasicAuthWithConfig(c)
}

func BasicAuthWithConfig(config BasicAuthConfig) echo.MiddlewareFunc {
	// 如果没有传入 认证方法，直接 panic
	if config.Validator == nil {
		panic("echo: basic-auth middleware requires a validator function")
	}
	// Skipper 方法: 可以用来跳过 中间件认证
	if config.Skipper == nil {
		config.Skipper = DefaultBasicAuthConfig.Skipper
	}
	// ?????
	if config.Realm == "" {
		config.Realm = defaultRealm
	}

	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			// 如果需要跳过，直接 执行 next
			if config.Skipper(c) {
				return next(c)
			}

			// 从 Header 的 Authorization 字段中取值
			auth := c.Request().Header.Get(echo.HeaderAuthorization)
			l := len(basic)

			if len(auth) > l+1 && strings.ToLower(auth[:l]) == basic {
				// base64 解码
				b, err := base64.StdEncoding.DecodeString(auth[l+1:])
				if err != nil {
					return err
				}
				cred := string(b)
				for i := 0; i < len(cred); i++ {
					// 找到 : 分割，取出 username 和 passwd
					if cred[i] == ':' {
						// 调用自定义的 认证方法，传入的 是username passwd
						valid, err := config.Validator(cred[:i], cred[i+1:], c)
						if err != nil {
							return err
						} else if valid {
							// 认证成功
							return next(c)
						}
						break
					}
				}
			}

			// ????
			realm := defaultRealm
			if config.Realm != defaultRealm {
				realm = strconv.Quote(config.Realm)
			}

			// 认证失败后，返回头部 设置该 字段的值 WWW-Authenticate
			c.Response().Header().Set(echo.HeaderWWWAuthenticate, basic+" realm="+realm)
			return echo.ErrUnauthorized
		}
	}
}
