package echo

import (
	"bufio"
	"net"
	"net/http"
)

type (
	/*
		Response 封装了 HTTP的 ResponseWriter
		1> 内部有  beforeFuncs 和 afterFuncs，更加方便
	 */
	Response struct {
		echo        *Echo
		beforeFuncs []func()
		afterFuncs  []func()
		Writer      http.ResponseWriter
		Status      int
		Size        int64
		Committed   bool //用来标识是否已经调用过  writeHeader
	}
)

/*
	根据 http.ResponseWrite 和 Echo，来创建一个 Response对象
 */
func NewResponse(w http.ResponseWriter, e *Echo) (r *Response) {
	return &Response{Writer: w, echo: e}
}

/*
	Header: 返回将由 write中，将由 WriteHeader 发送的值
	1> 返回 http.Header是一个 map
	2> 在 WriteHeader 或 write 之后，修改 header 无作用，除非 headers 被声明为 Trailer
 */
// To suppress implicit response headers, set their value to nil.
// Example: https://golang.org/pkg/net/http/#example_ResponseWriter_trailers
func (r *Response) Header() http.Header {
	return r.Writer.Header()
}

/*
	注册一个方法（保存在属性中)，在 发送 response 之间，进行调用
 */
func (r *Response) Before(fn func()) {
	r.beforeFuncs = append(r.beforeFuncs, fn)
}
/*
	注册一个方法，在发送 response 之后进行调用
	注意: 如果  Content-Length 未知，则 所有 after 方法都不会进行执行
 */
func (r *Response) After(fn func()) {
	r.afterFuncs = append(r.afterFus, fn)
}

/*
	WriteHeader: 发送 http response header (带有 状态码 )
	1> 如果 WriteHeader 未被显示调用，则会在 第一次 调用 Write时，触发一个隐士的 WriteHeader,
		此时 status code 是  http.StatusOk
	2> 一般显示调用 该方法，主要是来返回 错误码
 */
func (r *Response) WriteHeader(code int) {
	// 如果已经提交过，再次调用无效
	if r.Committed {
		r.echo.Logger.Warn("response already committed")
		return
	}
	for _, fn := range r.beforeFuncs {
		fn()
	}
	r.Status = code
	r.Writer.WriteHeader(code)
	r.Committed = true
}

/*
	Write：返回消息
 */
func (r *Response) Write(b []byte) (n int, err error) {
	// 判断是否已经调用过 WriteHeader,如果无，显示调用一次
	if !r.Committed {
		if r.Status == 0 {
			r.Status = http.StatusOK
		}
		r.WriteHeader(r.Status)
	}
	n, err = r.Writer.Write(b)
	r.Size += int64(n)
	// 每次调用 Write,都调用 aferFuncs方法吗
	for _, fn := range r.afterFuncs {
		fn()
	}
	return
}

/*
	TODO: Flush: 实现了 http.Flusher 接口
	1> 用来 将buffered 数据，强制发送到 client
 */
func (r *Response) Flush() {
	r.Writer.(http.Flusher).Flush()
}

/*
	TODO: Hijack: 实现 http.Hijacker 接口
 */
func (r *Response) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return r.Writer.(http.Hijacker).Hijack()
}

/*
	重置 Response 的内容
 */
func (r *Response) reset(w http.ResponseWriter) {
	r.beforeFuncs = nil
	r.afterFuncs = nil
	r.Writer = w
	r.Size = 0
	r.Status = http.StatusOK
	r.Committed = false
}
